"use strict";

// imports 
const express = require("express");
const bodyParser = require("body-parser");
const requestHandlers = require("./scripts/request-handlers.js");
const options = require("./scripts/options.json").server;

// nível 2
// start app


// nível 2
// middleware


// nível 3
// routing


// nível 2
// start server
