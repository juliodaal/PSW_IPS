"use strict";
const mysql = require("mysql");
const options = require("./options.json").database;

// nível 4